# ICT Gold AI Android App

Features:
- ICT Gold AI HTML app packaged in Android WebView
- Portrait mobile layout
- JavaScript + DOM storage enabled
- Internet permission enabled
- App name: ICT Gold AI
- Custom gold-chart style launcher icon
- Black system bars
- Android Studio/Gradle project ready to build

Build:
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).
4. APK: app/build/outputs/apk/debug/app-debug.apk
